import argparse
from datetime import datetime
from scraper import PulseScraper

def main():
    parser = argparse.ArgumentParser(description="Pulse Scraper Tool")
    parser.add_argument("--company", required=True, help="Company Name")
    parser.add_argument("--start", required=True, help="Start Date YYYY-MM-DD")
    parser.add_argument("--end", required=True, help="End Date YYYY-MM-DD")
    parser.add_argument("--source", required=True, choices=['G2', 'Capterra', 'TrustRadius'])

    args = parser.parse_args()

    # Parsing dates from inputs
    try:
        start_dt = datetime.strptime(args.start, '%Y-%m-%d')
        end_dt = datetime.strptime(args.end, '%Y-%m-%d')
    except ValueError:
        print("[-] Error: Use YYYY-MM-DD format for dates.")
        return

    engine = PulseScraper()
    final_data = engine.scrape_source(args.company, start_dt, end_dt, args.source)
    engine.save_to_json(final_data)

if __name__ == "__main__":
    main()