import random
import time
import json
from datetime import datetime
from models import Review

class PulseScraper:
    def _init_(self):
        self.results = []

    def human_delay(self):
        """Mimics human pauses to avoid being blocked by websites."""
        time.sleep(random.uniform(1.0, 2.5))

    def scrape_source(self, company, start_date, end_date, source):
        print(f"[*] Fetching data from {source} for {company}...")
        self.human_delay()
        
        # Mock data representing extracted reviews
        mock_data = [
            {
                "title": f"Excellent tool for {company}",
                "description": f"I've used {company} for years. Best in class performance.",
                "date": datetime(2024, 12, 10), 
                "rating": 5.0,
                "reviewer_name": "Nikhil Raj",
                "source": source
            },
            {
                "title": "A bit pricey",
                "description": "Works well but the monthly cost for teams is quite high.",
                "date": datetime(2024, 11, 5),
                "rating": 3.5,
                "reviewer_name": "SaaS Reviewer",
                "source": source
            }
        ]

        filtered_reviews = []
        for item in mock_data:
            # Pydantic validation: Ensure the date is within range
            if start_date <= item['date'] <= end_date:
                review_obj = Review(**item)
                review_obj.add_sentiment() # The Novelty Feature
                filtered_reviews.append(review_obj.model_dump())

        return filtered_reviews

    def save_to_json(self, data, filename="output.json"):
        # Saves structured data to JSON format as required
        with open(filename, 'w') as f:
            json.dump(data, f, indent=4, default=str)
        print(f"[+] Output file '{filename}' created successfully!")