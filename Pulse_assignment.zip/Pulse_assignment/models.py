from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from textblob import TextBlob

class Review(BaseModel):
    title: str
    description: str
    date: datetime
    rating: float
    reviewer_name: str = "Anonymous"
    source: str
    sentiment: Optional[str] = None

    def add_sentiment(self):
        # This is your novelty feature: It classifies the review tone
        analysis = TextBlob(self.description)
        if analysis.sentiment.polarity > 0:
            self.sentiment = "Positive"
        elif analysis.sentiment.polarity < 0:
            self.sentiment = "Negative"
        else:
            self.sentiment = "Neutral"